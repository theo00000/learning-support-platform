import { useState } from "react";
import { Link, useNavigate } from "react-router";

export function LoginPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = login({
      email: formData.email,
      password: formData.password,
    });

    setLoading(false);

    if (result.success) {
      toast.success(result.message);
      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
    } else {
      toast.error(result.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">
            Learning Support Platform
          </h1>
          <p className="text-gray-600 mt-2">
            Platform Belajar untuk Siswa SMA Kelas 12
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Selamat Datang Kembali</CardTitle>
            <CardDescription>Login untuk melanjutkan belajar</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="nama@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <a href="#" className="text-sm text-blue-600 hover:underline">
                    Lupa password?
                  </a>
                </div>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Masukkan password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-xs text-blue-800">
                  💡 <strong>Demo Mode:</strong> Gunakan email dan password yang
                  sama dengan saat register, atau buat akun baru.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full" disabled={loading}>
                <LogIn className="w-4 h-4 mr-2" />
                {loading ? "Memproses..." : "Login"}
              </Button>
              <p className="text-sm text-center text-gray-600">
                Belum punya akun?{" "}
                <Link to="/register" className="text-blue-600 hover:underline">
                  Daftar sekarang
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>

        <div className="mt-6 p-4 bg-white rounded-lg border border-gray-200">
          <p className="text-sm text-gray-700 mb-2">
            <strong>Fitur Platform:</strong>
          </p>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>✓ Materi lengkap untuk ujian akhir</li>
            <li>✓ 6 mata pelajaran utama</li>
            <li>✓ Akses materi kapan saja</li>
            <li>✓ Gratis untuk siswa SMA kelas 12</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
