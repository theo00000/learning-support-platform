import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { toast } from "sonner";

export function DashboardPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split(".")[1]));
        return { name: payload.name, email: payload.email };
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const handleLogout = () => {
    localStorage.removeItem("token");
    toast.success("Logged out successfully");
    setTimeout(() => {
      navigate("/login");
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold mb-4">
          Welcome, {user ? user.name : "Guest"}!
        </h1>
        <p className="text-gray-600 mb-6">
          This is your dashboard where you can access all your learning
          materials and track your progress.
        </p>
        <div className="space-y-4">
          <Link
            to="/materials"
            className="block w-full text-center bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition"
          >
            View Materials
          </Link>
          <Link
            to="/progress"
            className="block w-full text-center bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition"
          >
            Track Progress
          </Link>
          <button
            onClick={handleLogout}
            className="block w-full text-center bg-red-600 text-white py-3 rounded-lg font-bold hover:bg-red-700 transition"
          >
            Logout
          </button>
        </div>
      </div>
      <div className="mt-8 text-center">
        <p className="text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} E-Learning. All rights reserved.
        </p>
        <p className="text-gray-500 text-sm">
          Designed and developed with ❤️ by the Karang Taruna Team.
        </p>
        <p className="text-gray-500 text-sm">
          Empowering youth through education, one click at a time.
        </p>
        <p className="text-gray-500 text-sm">
          Stay curious, keep learning, and make a difference in your community
        </p>
        <p className="text-gray-500 text-sm">
          Your journey to knowledge starts here. Let's make the most of it
          together!
        </p>
      </div>
    </div>
  );
}
